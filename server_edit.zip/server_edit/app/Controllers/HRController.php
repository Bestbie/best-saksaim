<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class HRController extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();
        $data['users'] = $userModel->findAll(); // ดึงข้อมูลทั้งหมดจากตาราง users

        return view('hr/dashboard', $data);// ส่งข้อมูลไปยัง view
    }
}
