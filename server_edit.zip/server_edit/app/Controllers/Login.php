<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Login extends Controller

{
    public function index()
    {
        helper(['form']);
        echo view('login');
    }

    public function auth()
    {
        $model = new UserModel();
        $session = session();

        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        $data = $model->where('email', $email)->first();

        if ($data) {
            $pass = $data['password'];
            $verify_password = password_verify($password, $pass);
            if ($verify_password) {
                $ses_data = [
                    'user_id' => $data['user_id'],
                    'username' => $data['username'],
                    'email' => $data['email'],
                    'role_id' => (int) $data['role_id'],
                    'logged_in' => TRUE
                ];
                $session->set($ses_data);
                var_dump($data['role_id']);
                // dd($session->get('role_id'));


                if ((int)$data['role_id'] == 1) {
                    echo "Admin redirect";
                    return redirect()->to('/admin/dashboard');
                } elseif ((int)$data['role_id'] == 2) {
                    echo "HR redirect";
                    return redirect()->to('/hr/dashboard');
                } else {
                    echo "User redirect";
                    return redirect()->to('/user/dashboard');
                }
              
            } else {
                $session->setFlashdata('msg', 'Wrong password');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Email not found');
            return redirect()->to('/login');
        }
    }
}
