<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;
/**
 * @var RouteCollection $routes
    */           
$routes = Services::routes();
    
                //Ctrl::function
$routes->get('/', 'Home::index');

$routes->get('/login', 'Login::index');
$routes->post('/login/auth', 'Login::auth');
$routes->get('/logout', 'AuthController::logout');

$routes->get('/admin/dashboard', 'AdminController::index',['filter' => 'auth']);



$routes->get('/hr/dashboard', 'HRController::index',['filter' => 'auth']);
// $routes->get('/user/dashboard', 'UserController::index', ['filter' => 'auth']);

$routes->get('/user/dashboard', 'UserController::index',['filter' => 'auth']);
