<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hr List</title>
</head>
<body>
<?php $session = session(); ?>
    <h2> hr hello</h2>
    <h3><?php echo "Welcome back, " . $session->get('username'); ?></h3>
</body>
</html>
