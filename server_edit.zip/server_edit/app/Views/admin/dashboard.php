<?php $session = session(); ?>
<h1>Hello World</h1>
<h3><?php echo "Welcome back, " . $session->get('username'); ?></h3>