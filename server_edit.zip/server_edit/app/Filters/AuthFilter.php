<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // $session = session();
        
        // if (!$session->get('isLoggedIn')) {
        //     return redirect()->to('/login');
        // }

        // // Check role
        // if ($arguments) {                                                                                   
        //     $role = $session->get('role_id');
        //     if (!in_array($role, $arguments)) {
        //         return redirect()->to('/login');
        //     }
        // }
        
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $role_id = session()->get('role_id');

        if ($arguments && !in_array($role_id, $arguments)) {
            return redirect()->to('/login');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something after the request
    }
}
